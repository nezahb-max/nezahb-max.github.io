import com.comsol.model.*;
import com.comsol.model.util.*;
import java.io.*;
import java.util.*;

/** Original axisymmetric current-loop teaching model. Run in a new directory. */
public class MagnetLoop {
static double metric(Model m,String expr) {
 String tag="center";
 if(!Arrays.asList(m.result().dataset().tags()).contains("cpt1")) {
 m.result().dataset().create("cpt1","CutPoint2D");
 m.result().dataset("cpt1").set("pointx","0");m.result().dataset("cpt1").set("pointy","0");
 m.result().numerical().create(tag,"EvalPoint");m.result().numerical(tag).set("data","cpt1");
 }
 m.result().numerical(tag).set("expr",new String[]{expr});return m.result().numerical(tag).getReal()[0][0];
}
static Model build(double box,double hmax) throws Exception {
 Model m=ModelUtil.create("Loop");m.modelPath(".");m.label("05-axisymmetric-current-loop.mph");
 m.param().set("Rloop","20[mm]");m.param().set("awire","0.5[mm]");m.param().set("NI","100[A]");
 m.param().set("Lair",box+"[mm]");m.param().set("Jphi","NI/(pi*awire^2)");
 m.param().set("Bcenter_ref","mu0_const*NI/(2*Rloop)");
 m.component().create("comp1",true);m.component("comp1").geom().create("geom1",2);
 m.component("comp1").geom("geom1").axisymmetric(true);m.component("comp1").geom("geom1").lengthUnit("mm");
 m.component("comp1").geom("geom1").create("air","Rectangle");
 m.component("comp1").geom("geom1").feature("air").set("size",new String[]{"Lair","2*Lair"});
 m.component("comp1").geom("geom1").feature("air").set("pos",new String[]{"0","-Lair"});
 m.component("comp1").geom("geom1").create("wire","Circle");
 m.component("comp1").geom("geom1").feature("wire").set("r","awire");
 m.component("comp1").geom("geom1").feature("wire").set("pos",new String[]{"Rloop","0"});
 m.component("comp1").geom("geom1").feature("wire").set("selresult","on");
 m.component("comp1").geom("geom1").feature("wire").label("Current loop cross section");
 m.component("comp1").geom("geom1").run();
 m.component("comp1").material().create("airmat","Common");m.component("comp1").material("airmat").selection().all();
 m.component("comp1").material("airmat").label("Nonmagnetic background and ideal imposed-current region");
 m.component("comp1").material("airmat").propertyGroup("def").set("relpermeability",new String[]{"1","0","0","0","1","0","0","0","1"});
 m.component("comp1").material("airmat").propertyGroup("def").set("electricconductivity",new String[]{"0","0","0","0","0","0","0","0","0"});
 m.component("comp1").material("airmat").propertyGroup("def").set("relpermittivity",new String[]{"1","0","0","0","1","0","0","0","1"});
 m.component("comp1").physics().create("mf","InductionCurrents","geom1");
 m.component("comp1").physics("mf").create("ext1","ExternalCurrentDensity",2);
 m.component("comp1").physics("mf").feature("ext1").selection().named("geom1_wire_dom");
 m.component("comp1").physics("mf").feature("ext1").set("Je",new String[]{"0","Jphi","0"});
 m.component("comp1").physics("mf").feature("ext1").label("Azimuthal source current, 100 ampere-turns");
 m.component("comp1").mesh().create("mesh1");m.component("comp1").mesh("mesh1").autoMeshSize(4);
 m.component("comp1").mesh("mesh1").feature("size").set("custom","on");
 m.component("comp1").mesh("mesh1").feature("size").set("hmax",hmax+"[mm]");
 m.component("comp1").mesh("mesh1").create("wireSize","Size");
 m.component("comp1").mesh("mesh1").feature("wireSize").selection().geom("geom1",2);
 m.component("comp1").mesh("mesh1").feature("wireSize").selection().named("geom1_wire_dom");
 m.component("comp1").mesh("mesh1").feature("wireSize").set("custom","on");
 m.component("comp1").mesh("mesh1").feature("wireSize").set("hmaxactive",true);
 m.component("comp1").mesh("mesh1").feature("wireSize").set("hmax","awire/3");
 m.component("comp1").mesh("mesh1").create("ftri1","FreeTri");
 m.component("comp1").mesh("mesh1").run();
 m.study().create("std1");m.study("std1").create("stat","Stationary");m.study("std1").run();
 m.result().create("pgfield","PlotGroup2D");m.result("pgfield").label("Magnetic field magnitude and field lines");
 m.result("pgfield").create("surf1","Surface");m.result("pgfield").feature("surf1").set("expr","mf.normB");m.result("pgfield").feature("surf1").set("unit","mT");
 m.result("pgfield").create("str1","Streamline");m.result("pgfield").feature("str1").set("expr",new String[]{"mf.Br","mf.Bz"});
 m.result().dataset().create("axisline","CutLine2D");m.result().dataset("axisline").set("genpoints",new String[][]{{"0","-60[mm]"},{"0","60[mm]"}});
 m.result().create("pgaxis","PlotGroup1D");m.result("pgaxis").label("On-axis field versus Biot-Savart reference");m.result("pgaxis").set("data","axisline");
 m.result("pgaxis").create("lngr1","LineGraph");m.result("pgaxis").feature("lngr1").set("expr","mf.Bz");m.result("pgaxis").feature("lngr1").set("unit","mT");
 m.result("pgaxis").feature("lngr1").set("xdata","expr");m.result("pgaxis").feature("lngr1").set("xdataexpr","z");m.result("pgaxis").feature("lngr1").set("xdataunit","mm");
 m.result("pgaxis").create("lngr2","LineGraph");m.result("pgaxis").feature("lngr2").set("expr","mu0_const*NI*Rloop^2/(2*(Rloop^2+z^2)^(3/2))");m.result("pgaxis").feature("lngr2").set("unit","mT");
 m.result("pgaxis").feature("lngr2").set("xdata","expr");m.result("pgaxis").feature("lngr2").set("xdataexpr","z");m.result("pgaxis").feature("lngr2").set("xdataunit","mm");
 return m;
}
public static void main(String[] args) throws Exception {
 Model m=build(160,2);
 double center=metric(m,"mf.Bz");
 System.out.println("MAGNET_BASELINE_CENTER_T="+center);
 System.out.println("MAGNET_REFERENCE_T="+metric(m,"mu0_const*NI/(2*Rloop)"));
 m.result().export().create("axisdata","Data");m.result().export("axisdata").set("data","axisline");
 m.result().export("axisdata").set("expr",new String[]{"z","mf.Bz","mu0_const*NI*Rloop^2/(2*(Rloop^2+z^2)^(3/2))"});
 m.result().export("axisdata").set("unit",new String[]{"mm","mT","mT"});
 m.result().export("axisdata").set("filename","magnet-axis.csv");m.result().export("axisdata").run();
 m.save("05-axisymmetric-current-loop.mph");
 System.out.println("MAGNET_MODEL_SAVED");
}
}
