import com.comsol.model.*;
import com.comsol.model.util.*;
import java.io.*;
import java.util.*;

/** Original small teaching examples for the independent Hebrew COMSOL course.
 * Run from this directory with COMSOL 6.4. No external files or user data.
 */
public class CourseModels {
  static void param(Model m, String n, String v) { m.param().set(n,v); }
  static Model rectangle(String tag, String label, String length, String height) {
    Model m=ModelUtil.create(tag); m.label(label); m.modelPath(".");
    m.component().create("comp1",true); m.component("comp1").geom().create("geom1",2);
    m.component("comp1").geom("geom1").lengthUnit("mm");
    param(m,"L",length); param(m,"H",height); param(m,"d","1[mm]");
    m.component("comp1").geom("geom1").create("r1","Rectangle");
    m.component("comp1").geom("geom1").feature("r1").set("size",new String[]{"L","H"});
    m.component("comp1").geom("geom1").run();
    select(m,"left",1,new int[]{1}); select(m,"bottom",1,new int[]{2});
    select(m,"top",1,new int[]{3}); select(m,"right",1,new int[]{4});
    m.component("comp1").material().create("mat1","Common");
    m.component("comp1").material("mat1").selection().all();
    m.component("comp1").mesh().create("mesh1");
    m.component("comp1").mesh("mesh1").autoMeshSize(4);
    m.component("comp1").mesh("mesh1").run();
    m.component("comp1").cpl().create("intD","Integration");
    m.component("comp1").cpl("intD").selection().all();
    m.component("comp1").cpl().create("intR","Integration");
    m.component("comp1").cpl("intR").selection().geom("geom1",1);
    m.component("comp1").cpl("intR").selection().named("right");
    return m;
  }
  static void select(Model m,String name,int dim,int[] ids) {
    m.component("comp1").selection().create(name,"Explicit");
    m.component("comp1").selection(name).geom("geom1",dim);
    m.component("comp1").selection(name).set(ids);
    m.component("comp1").selection(name).label(name);
  }
  static void thermal(Model m) {
    m.component("comp1").physics().create("ht","HeatTransfer","geom1");
    m.component("comp1").physics("ht").prop("PhysicalModelProperty").set("dz","d");
    m.component("comp1").material("mat1").propertyGroup("def").set("thermalconductivity",new String[]{"k0","0","0","0","k0","0","0","0","k0"});
    m.component("comp1").material("mat1").propertyGroup("def").set("density","2700[kg/m^3]");
    m.component("comp1").material("mat1").propertyGroup("def").set("heatcapacity","900[J/(kg*K)]");
  }
  static void temperature(Model m,String tag,String selection,String value) {
    m.component("comp1").physics("ht").create(tag,"TemperatureBoundary",1);
    m.component("comp1").physics("ht").feature(tag).selection().named(selection);
    m.component("comp1").physics("ht").feature(tag).set("T0",value);
  }
  static void steady(Model m) {
    m.study().create("std1"); m.study("std1").create("stat","Stationary");
    m.study("std1").run();
  }
  static double[] global(Model m,String tag,String[] expr) {
    m.result().numerical().create(tag,"EvalGlobal");
    m.result().numerical(tag).set("expr",expr);
    double[][] a=m.result().numerical(tag).getReal();
    double[] out=new double[a.length]; for(int i=0;i<a.length;i++)out[i]=a[i][0];
    return out;
  }
  static void lineCSV(Model m,String file,String[] expr,String[] units) throws Exception {
    m.result().dataset().create("line1","CutLine2D");
    m.result().dataset("line1").set("genpoints",new String[][]{{"0","H/2"},{"L","H/2"}});
    m.result().export().create("data1","Data");
    m.result().export("data1").set("data","line1");
    m.result().export("data1").set("expr",expr);m.result().export("data1").set("unit",units);
    m.result().export("data1").set("filename",file);
    m.result().export("data1").run();
  }
  static void slab(PrintWriter summary) throws Exception {
    Model m=rectangle("Slab","01-steady-heat-slab.mph","40[mm]","10[mm]");
    param(m,"k0","10[W/(m*K)]");param(m,"TL","373.15[K]");param(m,"TR","293.15[K]"); thermal(m);
    temperature(m,"tempL","left","TL"); temperature(m,"tempR","right","TR");
    steady(m);
    double[] z=global(m,"metrics",new String[]{"intD(T)/(L*H)","d*intR((-k0*Tx))","sqrt(intD((T-(373.15[K]-80[K]*x/L))^2)/(L*H))"});
    summary.printf(Locale.US,"steady_slab,T_average,K,%.14g,333.15%n",z[0]);
    summary.printf(Locale.US,"steady_slab,power_right,W,%.14g,0.2%n",z[1]);
    summary.printf(Locale.US,"steady_slab,T_rms_error,K,%.14g,0%n",z[2]);
    lineCSV(m,"slab-centerline.csv",new String[]{"T","(-k0*Tx)"},new String[]{"K","W/m^2"});
    m.save("01-steady-heat-slab.mph"); summary.flush();
    System.out.println("COURSE_VERIFIED_SLAB "+Arrays.toString(z));
  }
  static void capacitor(PrintWriter summary) throws Exception {
    Model m=rectangle("Capacitor","02-ideal-capacitor.mph","20[mm]","2[mm]");
    param(m,"w","20[mm]");param(m,"g","2[mm]");param(m,"L","w");param(m,"H","g");param(m,"er","4");param(m,"V0","10[V]");
    m.component("comp1").material("mat1").propertyGroup("def").set("relpermittivity",new String[]{"er","0","0","0","er","0","0","0","er"});
    m.component("comp1").physics().create("es","Electrostatics","geom1");
    m.component("comp1").physics("es").prop("d").set("d","d");
    m.component("comp1").physics("es").create("gnd1","Ground",1);
    m.component("comp1").physics("es").feature("gnd1").selection().named("bottom");
    m.component("comp1").physics("es").create("pot1","ElectricPotential",1);
    m.component("comp1").physics("es").feature("pot1").selection().named("top");
    m.component("comp1").physics("es").feature("pot1").set("V0","V0");
    m.component("comp1").cpl().create("intTop","Integration");
    m.component("comp1").cpl("intTop").selection().geom("geom1",1);
    m.component("comp1").cpl("intTop").selection().named("top");
    steady(m);
    double[] z=global(m,"metrics",new String[]{"intD(es.Ey)/(L*H)","d*intTop(epsilon0_const*er*Vy)/V0","d*intD(epsilon0_const*er*(Vx^2+Vy^2)/2)","sqrt(intD((V-V0*y/H)^2)/(L*H))"});
    summary.printf(Locale.US,"ideal_capacitor,Ey,V/m,%.14g,-5000%n",z[0]);
    summary.printf(Locale.US,"ideal_capacitor,capacitance,F,%.14g,3.54167512512e-13%n",z[1]);
    summary.printf(Locale.US,"ideal_capacitor,field_energy,J,%.14g,1.77083756256e-11%n",z[2]);
    summary.printf(Locale.US,"ideal_capacitor,V_rms_error,V,%.14g,0%n",z[3]);
    m.save("02-ideal-capacitor.mph"); summary.flush();
    System.out.println("COURSE_VERIFIED_CAPACITOR "+Arrays.toString(z));
  }
  static void joule(PrintWriter summary) throws Exception {
    Model m=rectangle("Heater","04-joule-heater.mph","40[mm]","10[mm]");
    param(m,"k0","10[W/(m*K)]");param(m,"sigma0","1e5[S/m]");param(m,"V0","0.1[V]");param(m,"Tb","293.15[K]");
    thermal(m); temperature(m,"tempL","left","Tb"); temperature(m,"tempR","right","Tb");
    m.component("comp1").material("mat1").propertyGroup("def").set("electricconductivity",new String[]{"sigma0","0","0","0","sigma0","0","0","0","sigma0"});
    m.component("comp1").material("mat1").propertyGroup("def").set("relpermittivity",new String[]{"1","0","0","0","1","0","0","0","1"});
    m.component("comp1").physics().create("ec","ConductiveMedia","geom1");
    m.component("comp1").physics("ec").prop("d").set("d","d");
    m.component("comp1").physics("ec").create("gnd1","Ground",1);
    m.component("comp1").physics("ec").feature("gnd1").selection().named("right");
    m.component("comp1").physics("ec").create("pot1","ElectricPotential",1);
    m.component("comp1").physics("ec").feature("pot1").selection().named("left");
    m.component("comp1").physics("ec").feature("pot1").set("V0","V0");
    m.component("comp1").physics("ht").create("hs1","HeatSource",2);
    m.component("comp1").physics("ht").feature("hs1").selection().all();
    m.component("comp1").physics("ht").feature("hs1").set("Q0","sigma0*(Vx^2+Vy^2)");
    m.component("comp1").cpl().create("maxD","Maximum");
    m.component("comp1").cpl("maxD").selection().all();
    steady(m);
    double[] z=global(m,"metrics",new String[]{"d*intR(ec.Jx)","d*intD(ec.Jx*ec.Ex+ec.Jy*ec.Ey)","maxD(T)","sqrt(intD((T-(293.15[K]+sigma0*(V0/L)^2*x*(L-x)/(2*k0)))^2)/(L*H))"});
    summary.printf(Locale.US,"joule_heater,current,A,%.14g,2.5%n",z[0]);
    summary.printf(Locale.US,"joule_heater,power,W,%.14g,0.25%n",z[1]);
    summary.printf(Locale.US,"joule_heater,T_max,K,%.14g,305.65%n",z[2]);
    summary.printf(Locale.US,"joule_heater,T_rms_error,K,%.14g,0%n",z[3]);
    lineCSV(m,"joule-centerline.csv",new String[]{"T","V","ec.Jx"},new String[]{"K","V","A/m^2"});
    m.save("04-joule-heater.mph");summary.flush();
    System.out.println("COURSE_VERIFIED_JOULE "+Arrays.toString(z));
  }
  static void cooling(PrintWriter summary) throws Exception {
    Model m=ModelUtil.create("Cooling");m.label("03-sphere-cooling.mph");m.modelPath(".");
    param(m,"r0","2[mm]");param(m,"k0","200[W/(m*K)]");param(m,"rho0","2700[kg/m^3]");
    param(m,"Cp0","900[J/(kg*K)]");param(m,"hconv","10[W/(m^2*K)]");
    param(m,"Tamb","293.15[K]");param(m,"Ti","353.15[K]");
    m.component().create("comp1",true);m.component("comp1").geom().create("geom1",3);
    m.component("comp1").geom("geom1").lengthUnit("mm");
    m.component("comp1").geom("geom1").create("sph1","Sphere");
    m.component("comp1").geom("geom1").feature("sph1").set("r","r0");
    m.component("comp1").geom("geom1").run();
    m.component("comp1").material().create("mat1","Common");
    m.component("comp1").material("mat1").selection().all();
    m.component("comp1").material("mat1").propertyGroup("def").set("thermalconductivity",new String[]{"k0","0","0","0","k0","0","0","0","k0"});
    m.component("comp1").material("mat1").propertyGroup("def").set("density","rho0");
    m.component("comp1").material("mat1").propertyGroup("def").set("heatcapacity","Cp0");
    m.component("comp1").physics().create("ht","HeatTransfer","geom1");
    m.component("comp1").physics("ht").feature("init1").set("Tinit","Ti");
    m.component("comp1").physics("ht").create("hf1","HeatFluxBoundary",2);
    m.component("comp1").physics("ht").feature("hf1").selection().all();
    m.component("comp1").physics("ht").feature("hf1").set("HeatFluxType","ConvectiveHeatFlux");
    m.component("comp1").physics("ht").feature("hf1").set("h","hconv");
    m.component("comp1").physics("ht").feature("hf1").set("Text","Tamb");
    m.component("comp1").cpl().create("intD","Integration");m.component("comp1").cpl("intD").selection().all();
    m.component("comp1").cpl().create("intS","Integration");m.component("comp1").cpl("intS").selection().geom("geom1",2);m.component("comp1").cpl("intS").selection().all();
    m.component("comp1").mesh().create("mesh1");m.component("comp1").mesh("mesh1").autoMeshSize(6);m.component("comp1").mesh("mesh1").run();
    m.study().create("std1");m.study("std1").create("time","Transient");
    m.study("std1").feature("time").set("tlist","range(0,10,600)");
    m.study("std1").createAutoSequences("all");m.sol("sol1").feature("t1").set("rtol","1e-6");m.sol("sol1").runAll();
    m.result().numerical().create("coolMetrics","EvalGlobal");
    m.result().numerical("coolMetrics").set("expr",new String[]{"t","intD(T)/intD(1)","Tamb+(Ti-Tamb)*exp(-t/(rho0*Cp0*r0/(3*hconv)))","intS(hconv*(T-Tamb))","rho0*Cp0*intD(T-Tamb)"});
    double[][] a=m.result().numerical("coolMetrics").getReal();
    for(int j=0;j<a[0].length;j++) {
      System.out.printf(Locale.US,"COOLING_DATA,%.12g,%.12g,%.12g,%.12g,%.12g%n",a[0][j],a[1][j],a[2][j],a[3][j],a[4][j]);
    }
    int last=a[0].length-1;
    summary.printf(Locale.US,"sphere_cooling,T_average_600s,K,%.14g,%.14g%n",a[1][last],a[2][last]);
    m.save("03-sphere-cooling.mph");summary.flush();
    System.out.println("COURSE_VERIFIED_COOLING finalT="+a[1][last]);
  }
  public static Model run() {
    try {
      PrintWriter s=new PrintWriter(System.out,true);
      s.println("model,metric,unit,comsol_value,analytical_reference");
      slab(s);
      capacitor(s);
      joule(s);
      cooling(s);
    } catch(Exception e) { e.printStackTrace(); throw new RuntimeException(e); }
    return null;
  }
  public static void main(String[] args) { run(); }
}
