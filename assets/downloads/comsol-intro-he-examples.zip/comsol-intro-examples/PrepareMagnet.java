import com.comsol.model.*;
import com.comsol.model.util.*;
public class PrepareMagnet {
 static void clearMessages(SolverFeature f) {
  try{f.set("message","");}catch(Exception ignored){}
  for(String tag:f.feature().tags())clearMessages(f.feature(tag));
 }
 public static void main(String[] args) throws Exception {
 Model m=ModelUtil.load("PreparedMagnet","05-axisymmetric-current-loop.mph");
 m.result().numerical("center").label("COMSOL Bz at origin");
 m.result().numerical("center").set("expr",new String[]{"mf.Bz"});
 m.result().numerical("center").set("unit",new String[]{"mT"});
 m.result().table().create("tblcenter","Table");m.result().table("tblcenter").label("COMSOL field at the origin");
 m.result().numerical("center").set("table","tblcenter");m.result().numerical("center").setResult();
 m.result().numerical().create("center_ref","EvalGlobal");m.result().numerical("center_ref").label("Thin-loop analytical reference");
 m.result().numerical("center_ref").set("expr",new String[]{"Bcenter_ref"});m.result().numerical("center_ref").set("unit",new String[]{"mT"});
 m.result().table().create("tblref","Table");m.result().table("tblref").label("Analytical thin-loop reference at origin");
 m.result().numerical("center_ref").set("table","tblref");m.result().numerical("center_ref").setResult();
 m.result("pgaxis").feature("lngr1").set("legend",true);
 m.result("pgaxis").feature("lngr1").set("legendmethod","manual");m.result("pgaxis").feature("lngr1").set("legends",new String[]{"COMSOL"});
 m.result("pgaxis").feature("lngr2").set("legend",true);
 m.result("pgaxis").feature("lngr2").set("legendmethod","manual");m.result("pgaxis").feature("lngr2").set("legends",new String[]{"Thin-loop analytical reference"});
 m.result("pgaxis").run();m.result("pgfield").run();
 for(String sol:m.sol().tags())for(String f:m.sol(sol).feature().tags())clearMessages(m.sol(sol).feature(f));
 m.modelPath(".");m.save("public/05-axisymmetric-current-loop.mph");
 System.out.println("PREPARED_ACTUAL_MILLITESLA="+m.result().numerical("center").getReal()[0][0]);
 System.out.println("PREPARED_REFERENCE_MILLITESLA="+m.result().numerical("center_ref").getReal()[0][0]);
 ModelUtil.remove(m.tag());
 m=ModelUtil.load("ReloadMagnet","public/05-axisymmetric-current-loop.mph");
 System.out.println("RELOADED_ACTUAL_MILLITESLA="+m.result().numerical("center").getReal()[0][0]);
 }
}
