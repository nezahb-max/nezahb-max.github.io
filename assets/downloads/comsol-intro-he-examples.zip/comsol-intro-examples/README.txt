Output folder for optional data and image exports from the teaching models. Saved plots and numerical solutions are already stored in the MPH files.
