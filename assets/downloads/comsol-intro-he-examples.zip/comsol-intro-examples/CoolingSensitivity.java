import com.comsol.model.*;
import com.comsol.model.util.*;
import java.util.*;

/** Modest spatial/time-tolerance sensitivity check for an almost uniform sphere. */
public class CoolingSensitivity {
  static void measure(Model m,int meshSize,String tol) {
    m.sol("sol1").feature("t1").set("rtol",tol);m.sol("sol1").runAll();
    double[][] a=m.result().numerical("coolMetrics").getReal();
    int last=a[0].length-1;double maxerr=0;
    for(int j=0;j<a[0].length;j++)maxerr=Math.max(maxerr,Math.abs(a[1][j]-a[2][j]));
    System.out.printf(Locale.US,"COOLING_SENSITIVITY,%d,%s,%.12g,%.12g,%.12g%n",meshSize,tol,a[1][last],a[2][last],maxerr);
  }
  public static Model run() {
    try {
      Model m=ModelUtil.load("Sensitivity","03-sphere-cooling.mph");
      for(int size:new int[]{8,7,6}) {
        m.component("comp1").mesh("mesh1").autoMeshSize(size);m.component("comp1").mesh("mesh1").run();
        measure(m,size,"1e-5");
      }
      for(String tol:new String[]{"1e-3","1e-4","1e-6"}) measure(m,6,tol);
      m.save("03-sphere-cooling.mph");return m;
    }catch(Exception e){throw new RuntimeException(e);}
  }
  public static void main(String[] args){run();}
}
