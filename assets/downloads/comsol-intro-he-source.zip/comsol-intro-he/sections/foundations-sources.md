# Research sources for fundamentals pages 5–15

Checked 2026-10-28. Original instructional prose and exercises, using official documentation for product names and workflow. No private research assets used.

- Page 5: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_environment.18.42.html — File > New, Model Wizard, blank model, cross-platform location differences.
- Page 5 supplementary: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/IntroductionToCOMSOLMultiphysics.pdf — physics list depends on installed modules; Heat Transfer in Solids, Add/Study/Done UI. Do not copy its vendor tutorial.
- Page 6: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_environment.18.05.html — roles of Model Builder, Settings, Graphics, Messages, application documentation.
- Page 7: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_modeling.19.007.html — Component holds geometry/physics/mesh, dimension options. Physical model assumptions and original slab illustration are author-developed explanation.
- Page 8: https://www.comsol.com/multiphysics/finite-element-method — finite element background; heat equation and explanation are generic physics written independently.
- Page 9: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_definitions.21.008.html — Parameters/Variables distinction, scope, case sensitivity, reserved names.
- Page 9 supplementary: https://doc.comsol.com/6.4/doc/com.comsol.help.mems/mems_introduction.02.06.html — square-bracket unit syntax and Global Definitions parameter table.
- Page 10: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_visualizationselection.22.15.html — Definitions > Selections, Explicit selections, geometric entity levels, create-selection workflow.
- Page 11: https://doc.comsol.com/6.4/doc/com.comsol.help.acdc/acdc_introduction.02.23.html — Blank Material, material label, geometric selection, Material Contents workflow. Numerical teaching material is original, not an asserted real alloy.
- Page 12: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_modeling.19.065.html — Initial Values as initial conditions for transient study and initial guess for nonlinear stationary solvers. Flux sign explanation is direct Fourier-law derivation.
- Page 13: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_mesh.24.11.html — Physics-controlled vs user-controlled, Normal/Fine, Build All, non-equivalence to adaptive error estimates.
- Page 14: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_solver.36.006.html — Stationary, Time Dependent, Frequency Domain study meaning. https://doc.comsol.com/6.4/doc/com.comsol.help.acdc/acdc_ug_modeling.06.07.html — time-harmonic complex amplitude/phase and transient distinction.
- Page 15: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_results.37.091.html — Derived Values definitions by geometric dimension. https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_results.37.027.html — integration dimension and axisymmetric factors.

Editorial note: thermal out-of-plane integrated quantities must be handled consistently with the specific physics/node options; chapter deliberately teaches explicit dimensional checks and no implicit double multiplication of thickness.
