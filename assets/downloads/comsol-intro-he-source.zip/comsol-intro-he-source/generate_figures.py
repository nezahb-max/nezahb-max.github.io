"""Original analytical teaching illustrations. No image is a COMSOL screenshot."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'images'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,
 'axes.spines.right':False,'axes.labelcolor':'#17324d','text.color':'#17324d',
 'axes.prop_cycle':plt.cycler(color=['#007f86','#dc8b29','#486ec0']),
 'pdf.fonttype':42,'savefig.bbox':'tight'})

def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'),facecolor='white',metadata={'Author':'COMSOL introductory course','Subject':'Original analytical reference illustration'})
    fig.savefig(OUT/(name+'.png'),dpi=180,facecolor='white')
    plt.close(fig)

x=np.linspace(0,.04,401)
T=293.15+1e6/(2*10)*x*(.04-x)
fig,ax=plt.subplots(figsize=(8,3.4))
y=np.linspace(0,10,51)
im=ax.pcolormesh(x*1000,y,np.tile(T-273.15,(len(y),1)),cmap='inferno',shading='auto')
ax.set(xlabel='x (mm)',ylabel='y (mm)',aspect='equal')
fig.colorbar(im,ax=ax,label='Temperature (°C)',shrink=.75,pad=.02)
ax.set_title('Uniform volumetric heat source • analytical reference',pad=15)
save(fig,'cover-field')

fig,ax=plt.subplots(figsize=(8,2.8))
ax.add_patch(Rectangle((0,0),40,10,facecolor='#edf6f7',edgecolor='#17324d',linewidth=1.5))
ax.plot([0,0],[0,10],color='#df6d35',lw=5)
ax.plot([40,40],[0,10],color='#3676c5',lw=5)
ax.annotate('Heat flow',xy=(28,5),xytext=(12,5),arrowprops={'arrowstyle':'->','color':'#007f86','lw':2},ha='center',va='center')
ax.text(0,13,'373.15 K',ha='center');ax.text(40,13,'293.15 K',ha='center')
ax.text(20,11.5,'Insulation',ha='center');ax.text(20,-3,'L = 40 mm, H = 10 mm, d = 1 mm',ha='center')
ax.set(xlim=(-7,47),ylim=(-5,17),aspect='equal');ax.axis('off')
save(fig,'heat-geometry')

fig,ax=plt.subplots(figsize=(7.5,3))
ax.plot(x*1000,373.15-2000*x,lw=2.8,label='Analytical T(x)')
ax.scatter([20],[333.15],s=36,color='#dc8b29',zorder=4,label='Midpoint = 333.15 K')
ax.set(xlabel='x (mm)',ylabel='Temperature (K)',xlim=(0,40),ylim=(288,380))
ax.legend(frameon=False);ax.grid(alpha=.18)
save(fig,'heat-reference')

fig,axs=plt.subplots(1,2,figsize=(8,3),gridspec_kw={'width_ratios':[1.2,1]})
ax=axs[0]
ax.add_patch(Rectangle((0,0),20,2,facecolor='#edf6f7',edgecolor='#007f86'))
ax.plot([0,20],[2,2],lw=4,color='#df6d35');ax.plot([0,20],[0,0],lw=4,color='#3676c5')
for xx in [3,7,11,15,19]:ax.annotate('',xy=(xx,.2),xytext=(xx,1.8),arrowprops={'arrowstyle':'->','color':'#007f86'})
ax.text(10,2.7,'V = 10 V',ha='center');ax.text(10,-.8,'V = 0 V',ha='center')
ax.text(10,1,'εr = 4',ha='center',bbox={'facecolor':'white','edgecolor':'none'})
ax.set(xlim=(-2,22),ylim=(-1.5,4),aspect=3);ax.axis('off')
yy=np.linspace(0,2,101)
axs[1].plot(10*yy/2,yy,lw=2.5)
axs[1].set(xlabel='Potential (V)',ylabel='y (mm)',xlim=(0,10),ylim=(0,2))
axs[1].grid(alpha=.18)
fig.tight_layout();save(fig,'capacitor-reference')

t=np.linspace(0,600,301)
tc=293.15+60*np.exp(-t/162)
fig,ax=plt.subplots(figsize=(7.5,3.2))
ax.plot(t,tc,lw=2.7,label='Lumped reference: τ = 162 s')
ax.axhline(293.15,color='#526578',ls='--',label='Ambient: 293.15 K')
ax.scatter([162],[293.15+60/np.e],color='#dc8b29',zorder=3)
ax.annotate('315.22 K at one time constant',xy=(162,293.15+60/np.e),xytext=(220,331),arrowprops={'arrowstyle':'->','color':'#526578'},fontsize=9)
ax.set(xlabel='Time (s)',ylabel='Temperature (K)',xlim=(0,600),ylim=(288,358))
ax.legend(frameon=False,fontsize=9);ax.grid(alpha=.18)
save(fig,'cooling-reference')

fig,ax=plt.subplots(figsize=(7.5,3.2))
for v in [.1,.2,.4]:
    q=1e5*(v/.04)**2
    ax.plot(x*1000,293.15+q/(2*10)*x*(.04-x),lw=2,label=f'V₀ = {v:g} V')
ax.set(xlabel='x (mm)',ylabel='Temperature (K)',xlim=(0,40))
ax.legend(frameon=False);ax.grid(alpha=.18)
save(fig,'joule-reference')

# Formula-based validation values; these are never labelled COMSOL output.
refs={'origin':'independent analytical calculations from handbook formulas',
 'heat':{'Tmid_K':333.15,'power_W':.2},
 'capacitor':{'Ey_V_per_m':-5000,'C_pF':8.8541878128e-12*4*.02*.001/.002*1e12},
 'cooling':{'tau_s':162,'Bi':10*(.002/3)/200,
 'T_K':{str(z):float(293.15+60*np.exp(-z/162)) for z in [0,60,120,162,300,600]}},
 'joule':{str(v):{'I_A':1e5*(v/.04)*.01*.001,'P_W':v*v/.04,
 'Tmax_K':293.15+1e5*v*v/(8*10)} for v in [.1,.2,.4]}}
(ROOT/'validation'/'analytical-references.json').write_text(json.dumps(refs,indent=2),encoding='utf-8')
print('Generated 6 original figures and analytical reference data.')
