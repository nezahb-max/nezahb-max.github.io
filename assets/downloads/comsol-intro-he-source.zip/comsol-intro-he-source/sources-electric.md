# Primary sources for electric and transient sections

Accessed 2026-10-28. Original course examples and calculations are independently derived. No copied vendor figures or models.

- Electrostatics equations, potential and 2D assumption: https://doc.comsol.com/6.4/doc/com.comsol.help.edis/edis_ug_acdc.7.71.html
- Electrostatics interface tree and out-of-plane thickness (documentation packaged with Plasma product, common interface): https://doc.comsol.com/6.4/doc/com.comsol.help.plasma/plasma_ug_acdc.14.02.html
- Base Electrostatics available boundary nodes: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_acdc.26.29.html
- Cut Line datasets and coordinate units: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_results.37.049.html
- Cut Line -> 1D plot -> Line Graph workflow: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_results.37.115.html
- Derived Value types (geometrical dimensions of integration/average): https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_results.37.091.html
- Average types: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_results.37.092.html
- Integration settings and special axisymmetric weighting: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_results.37.027.html
- Heat flux UI example showing Heat Flux -> Convective heat flux, h, external temperature: https://doc.comsol.com/6.4/doc/com.comsol.help.heat/heat_introduction.02.08.html
- Initial temperature UI: https://doc.comsol.com/6.4/doc/com.comsol.help.heat/heat_ug_ht_features.09.019.html
- Heat Transfer in Solids defaults and context menu: https://doc.comsol.com/6.4/doc/com.comsol.help.heat/heat_ug_interfaces.08.31.html
- Output times differ from solver time steps, tightening tolerances: https://www.comsol.com/support/knowledgebase/1254
- Time Dependent study, tolerance selectors, interpolation: https://doc.comsol.com/6.4/doc/com.comsol.help.comsol/comsol_ref_solver.36.017.html

The text intentionally says license-dependent interfaces: no blanket assertion all UI features are included in every license. No Terminal functionality is required for the electrostatic exercise; explicit integrals permit checking thickness and sign.

Cooling reference numerical values independently computed:
T=293.15+60 exp(-t/162), t seconds. T(162)=315.2227664703K; T(324)=301.2701169942K; T(486)=296.1372241021K; T(600)=294.6279276330K. Volume=3.3510321638e-8m3, area=5.0265482457e-5m2, heat capacity=0.0814300815810J/K, U0=4.88580489486J, P0=0.0301592894745W. Forty Celsius crossing=177.975190764s.
